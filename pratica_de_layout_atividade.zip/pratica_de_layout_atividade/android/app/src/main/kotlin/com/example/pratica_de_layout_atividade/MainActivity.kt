package com.example.pratica_de_layout_atividade

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
