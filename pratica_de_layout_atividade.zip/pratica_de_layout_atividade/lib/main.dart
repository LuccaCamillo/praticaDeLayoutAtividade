import 'package:flutter/material.dart';
import 'LayoutCard.dart';
import 'LayoutImagem.dart';



void main() {
  runApp(MaterialApp(
    home: LayoutCard (),
    //home: LayoutImagem(),
  ));
}