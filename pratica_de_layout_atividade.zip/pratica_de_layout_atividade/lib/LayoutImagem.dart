import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LayoutImagem extends StatefulWidget {
  const LayoutImagem({Key? key}) : super(key: key);

  @override
  _LayoutImagemState createState() => _LayoutImagemState();
}

class _LayoutImagemState extends State<LayoutImagem> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Espaço"),
        backgroundColor: Colors.indigo,
      ),
      body: Container(
          padding: EdgeInsets.all(18),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,

            children: <Widget>[
              Image.asset("imagens/espaco.jpg"),

              RaisedButton(
                child: Text("<- BACK"),
                color: Colors.indigo,
                onPressed: (){
              },
            ),
          ],
        ),
      ),
    );
  }
}
