import 'package:flutter/material.dart';

class LayoutCard extends StatefulWidget {
  const LayoutCard({Key? key}) : super(key: key);

  @override
  _LayoutCardState createState() => _LayoutCardState();
}

class _LayoutCardState extends State<LayoutCard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Planetas"),
        backgroundColor: Colors.indigo,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column(


          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Image.asset('imagens/netuno.png'),
            RaisedButton(
              child: Text("<- DELETE"),
              color: Colors.indigo,
              onPressed: (){
              },
            ),
            Image.asset("imagens/planeta-terra.png"),
            RaisedButton(
              child: Text("<- DELETE"),
              color: Colors.indigo,
              onPressed: (){
              },
            ),
            Image.asset("imagens/plutao.png"),
            RaisedButton(
              child: Text("<- DELETE"),
              color: Colors.indigo,
              onPressed: (){
              },
            ),


          ],
        ),
      ),
    );
  }
}
