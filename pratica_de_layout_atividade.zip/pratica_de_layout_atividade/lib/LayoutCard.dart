import 'package:flutter/material.dart';

class LayoutCard extends StatefulWidget {
  const LayoutCard({Key? key}) : super(key: key);

  @override
  _LayoutCardState createState() => _LayoutCardState();
}

class _LayoutCardState extends State<LayoutCard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Planetas"),
        backgroundColor: Colors.indigo,
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[

            Image.asset('imagens/netuno.png'),
            Padding(padding: EdgeInsets.all(10),
            ),
            RaisedButton(
              child: Text("DELETE"),
              color: Colors.indigo,
              textColor: Colors.white,
              onPressed: (){
              },
            ),

            Padding(padding: EdgeInsets.all(20),
            ),
            Image.asset("imagens/planeta-terra.png"),
            Padding(padding: EdgeInsets.all(10),
            ),
            RaisedButton(
              child: Text("DELETE"),
              color: Colors.indigo,
              textColor: Colors.white,
              onPressed: (){
              },
            ),

            Padding(padding: EdgeInsets.all(20),
            ),
            Image.asset("imagens/plutao.png"),
            Padding(padding: EdgeInsets.all(10),
            ),
            RaisedButton(
              child: Text("DELETE"),
              color: Colors.indigo,
              textColor: Colors.white,
              onPressed: (){
              },
            ),
          ],
        ),
      ),
    );
  }
}
